from dotenv import load_dotenv
import os
load_dotenv()
print(f"Monitorando: {os.getenv('SEARCH_TERM')} até R$ {os.getenv('MAX_PRICE')}")
print("Em breve: integração com Shopee.")
