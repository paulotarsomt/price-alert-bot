# Price Alert Bot

Projeto inicial para monitorar preços na Shopee usando Python e GitHub Actions.

## Próximos passos
- Configurar Telegram
- Implementar busca na Shopee
